var searchData=
[
  ['manufacturer_5fname_148',['manufacturer_name',['../structms5837__info__s.html#ad25285dbf810c90f8eaf3fcef6f2b2ea',1,'ms5837_info_s']]],
  ['max_5fcurrent_5fma_149',['max_current_ma',['../structms5837__info__s.html#a9db82802561bf22d799b03a345f1d1dc',1,'ms5837_info_s']]]
];
