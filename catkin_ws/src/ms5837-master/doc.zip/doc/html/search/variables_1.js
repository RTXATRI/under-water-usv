var searchData=
[
  ['debug_5fprint_139',['debug_print',['../structms5837__handle__s.html#a769d5b3a6c14790a0e126e8fe70b384b',1,'ms5837_handle_s']]],
  ['delay_5fms_140',['delay_ms',['../structms5837__handle__s.html#a406c9433252b7366de417b7a60915c81',1,'ms5837_handle_s']]],
  ['driver_5fversion_141',['driver_version',['../structms5837__info__s.html#a41b0bd442708b70d252c50b92c75265a',1,'ms5837_info_s']]]
];
