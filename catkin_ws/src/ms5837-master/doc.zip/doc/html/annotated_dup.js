var annotated_dup =
[
    [ "ms5837_handle_s", "structms5837__handle__s.html", "structms5837__handle__s" ],
    [ "ms5837_info_s", "structms5837__info__s.html", "structms5837__info__s" ]
];