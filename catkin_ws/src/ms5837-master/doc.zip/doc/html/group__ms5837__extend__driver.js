var group__ms5837__extend__driver =
[
    [ "ms5837_get_reg", "group__ms5837__extend__driver.html#ga53c3c8fbe02bb7613be6bfcd4b1acc6e", null ],
    [ "ms5837_set_reg", "group__ms5837__extend__driver.html#ga5a25d98dd9c0672580736942b475fbbc", null ]
];