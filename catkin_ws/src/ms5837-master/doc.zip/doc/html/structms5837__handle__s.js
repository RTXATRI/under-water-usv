var structms5837__handle__s =
[
    [ "c", "structms5837__handle__s.html#a6857af6c02fb563297e3daa8b34f366b", null ],
    [ "debug_print", "structms5837__handle__s.html#a769d5b3a6c14790a0e126e8fe70b384b", null ],
    [ "delay_ms", "structms5837__handle__s.html#a406c9433252b7366de417b7a60915c81", null ],
    [ "iic_deinit", "structms5837__handle__s.html#af6963bbad902ca6e43942b48c07986c3", null ],
    [ "iic_init", "structms5837__handle__s.html#a8826dd07625f8d90859ce9bd09628d61", null ],
    [ "iic_read", "structms5837__handle__s.html#af4ef726288b88f51a846483803a1249b", null ],
    [ "iic_write", "structms5837__handle__s.html#adca3ee7a793bbf510d5267daf0fcf1c5", null ],
    [ "inited", "structms5837__handle__s.html#a19bedf28d2b9748f6a62d9ae93f4e68f", null ],
    [ "press_osr", "structms5837__handle__s.html#aae1a81db42aafdaa6d84078c43e7258a", null ],
    [ "prom", "structms5837__handle__s.html#a6d3c64564b8bfc226f0748fe705789ad", null ],
    [ "temp_osr", "structms5837__handle__s.html#aa8154e5c5e4b8e7951fb68092ac46f97", null ],
    [ "type", "structms5837__handle__s.html#a1d127017fb298b889f4ba24752d08b8e", null ]
];