var group__ms5837__example__driver =
[
    [ "MS5837_BASIC_DEFAULT_PRESSURE_OSR", "group__ms5837__example__driver.html#ga7601244a6aabcd600e1cf94e1a5d163f", null ],
    [ "MS5837_BASIC_DEFAULT_TEMPERATURE_OSR", "group__ms5837__example__driver.html#ga9bcc0a660ab6e81709106406ae9cf01c", null ],
    [ "ms5837_basic_deinit", "group__ms5837__example__driver.html#ga7458a0910217d886925f462e3e3eae2b", null ],
    [ "ms5837_basic_init", "group__ms5837__example__driver.html#gacbfba4b13b6faf477a7cdef8ff9d35b5", null ],
    [ "ms5837_basic_read", "group__ms5837__example__driver.html#gab412e6b0e2d70e4477e0c11cd187604c", null ]
];